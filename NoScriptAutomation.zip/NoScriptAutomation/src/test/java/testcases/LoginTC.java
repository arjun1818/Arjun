package testcases;

import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;

import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.LoginPage;






public class LoginTC extends BaseTest1{
	
	@DataProvider(name="noskriptdata")
	public Object[][] noskriptdata() throws IOException {
		JsonObject jsonObject = BaseUtils.getTestData();
		JsonObject appData = jsonObject.getAsJsonObject("testsuitecrud");
		Object[][] testData = new Object[1][9];
		
			
			testData[0][0] = appData.get("Username").getAsString();
			testData[0][1] = appData.get("Password").getAsString();
			testData[0][2] = appData.get("InvalidU").getAsString();
			testData[0][3] = appData.get("InvalidP").getAsString();
			testData[0][4] = appData.get("Username2").getAsString();
			testData[0][5] = appData.get("Password2").getAsString();
			testData[0][6] = appData.get("Uname3").getAsString();
			testData[0][7] = appData.get("Fullname2").getAsString();
			testData[0][8] = appData.get("Fullname1").getAsString();
			
			
			
		return testData;
		}
	
//Method to perform user login
	@Test(dataProvider="noskriptdata")
	public void loginTestInvalidUser(String uname,String pass, String inuname, String inpass,String U2,String P2,String Uname3, String fullname2, String fullname1) throws InterruptedException {
		
		
		LoginPage l1=new LoginPage(driver);
		
//Empty Username Password
		
		l1.Acceptclick();
		
		l1.SignInClick();
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed());
		});	
		
//Invalid Username and Password
		
		
		l1.UnameEnter(inuname);
		
		l1.Password1(inpass);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed());
		});
		
//username with special characters and numbers
		
        l1.UnameEnter(Uname3);
		
		l1.Password1(inpass);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed());
		});
		
		

		//Only Password
		l1.Password1(P2);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed());
		});
		
		//Only Username
		l1.UnameEnter(U2);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed());
		});
		
		//Short Full name
		
		 l1.UnameEnter(fullname1);
			
			l1.Password1(pass);
			
			l1.SignInbtnclick();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed());
			});
			
		//Long Full name
			
            l1.UnameEnter(fullname2);
			
			l1.Password1(pass);
			
			l1.SignInbtnclick();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@class='alert alert-error']")).isDisplayed());
			});
		
		

		
		
		
		
		
        //Valid Username and Password
		
		l1.ClearAndEnterUname(uname);
		Thread.sleep(2000);
		l1.Password1(pass);
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//a[@id='zocial-oidc']")).isDisplayed());
			
		});
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@id='kc-header-wrapper']")).isDisplayed());
		});
		l1.SignInbtnclick();
		Thread.sleep(2000);
		l1.ProjClick();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//img[@class='ns-logo']")).isDisplayed());
		});
		l1.Drop();
		l1.Logout();
//		Thread.sleep(2000);
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("(//a[@href='https://nsdev.azurewebsites.net/scriptless/beta/index.html'])[1]")).isDisplayed());
//		});
//		

}
}
