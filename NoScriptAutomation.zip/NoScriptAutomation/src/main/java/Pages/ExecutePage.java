package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseTest1;

public class ExecutePage extends BaseTest1{
	 WebDriver driver;
	 public ExecutePage(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	 @FindBy(xpath="//button[@routerlink='/execute']")
		private WebElement ExecuteButton;
		
		public void execute() {
			clickOn(ExecuteButton);
		}
		
		@FindBy(xpath="//button[@class='btn btn-primary']")
		private WebElement NewTestSuiteButton;
		
		public void NewTestSuite() {
			clickOn(NewTestSuiteButton);
		}
		
		@FindBy(xpath="//mat-select[@id='testingType']")
		private WebElement testingselect;
		
		public void TestingSelect() {
			clickOn(testingselect);
		}
		
		@FindBy(xpath="(//span[@class='mat-option-text'])[1]")
		private WebElement regressiontest;
		
		public void RegressionTest() {
			clickOn(regressiontest);
		}
		@FindBy(xpath="//input[@placeholder='Name']")
		private WebElement testsuitename;
		
		 public void TestSuiteName(String tsname) {
			 
				sendtext(testsuitename,tsname);
		}
		 
		 @FindBy(xpath="(//span[@class='mat-radio-label-content'])[2]")
			private WebElement cloud;
			
			public void Cloud() {
				clickOn(cloud);
			}
			
			 @FindBy(xpath="(//span[@class='mat-radio-label-content'])[1]")
				private WebElement local;
				
				public void Local() {
					clickOn(local);
				}
				
				@FindBy(xpath="//i[@title='Create Test Pack']")
				private WebElement createtestpack;
				
				public void CreateTestPack() {
					clickOn(createtestpack);
				}
				
				@FindBy(xpath="//select[@id='sel1']")
				private WebElement appselect;
				
				public void AppSelect() {
					clickOn(appselect);
				}
				
				@FindBy(xpath="//option[@value='726']")
				private WebElement apptest;
				
				public void AppTest() {
					clickOn(apptest);
				}
				
				@FindBy(xpath="//input[@id='testPackName']")
				private WebElement testpackname;
				
				 public void TestPackName(String tpname) {
					 
						sendtext(testpackname,tpname);
				}
				 
				 @FindBy(xpath="//label[@for='abc4687-input']")
					private WebElement testcasecheck;
					
					public void TestCaseCheck() {
						clickOn(testcasecheck);
					}
					
					 @FindBy(xpath="//i[@type='button']")
						private WebElement addbtn;
						
						public void AddButton() {
							clickOn(addbtn);
						}
						
						 @FindBy(xpath="//div[@title='demotestpack']")
							private WebElement tpclick;
							
							public void TestPackClick() {
								clickOn(tpclick);
							}
							
							@FindBy(xpath="//select[@id='envOpt']")
							private WebElement selectenv;
							
							public void EnvSelect() {
								clickOn(selectenv);
							}
							
							@FindBy(xpath="//option[@value='1991']")
							private WebElement env;
							
							public void Env() {
								clickOn(env);
							}
							
							@FindBy(xpath="(//span[@class='mat-checkbox-label'])[1]")
							private WebElement browserselect;
							
							public void Browser() {
								clickOn(browserselect);
							}
							
							@FindBy(xpath="//button[@class='btn btn-success foot__btns ng-binding ng-star-inserted']")
							private WebElement save;
							
							public void Save() {
								clickOn(save);
							}
							
							 public void ClearAndEnterTSname(String cleartsname) {
								 testsuitename.clear();
								 sendtext(testsuitename,cleartsname);
							 }
							 
							 public void ClearAndEnterTPname(String cleartpname) {
								 testpackname.clear();
								 sendtext(testpackname,cleartpname);
							 }
							
							 @FindBy(xpath="//*[normalize-space()='newtestsuite']/..//*[@title='Edit']")
								private WebElement update;
								
								public void Update() {
									clickOn(update);
								}
								
								@FindBy(xpath="//i[contains(@class,'fa fa-pencil icon__tealcolor')]")
								private WebElement editpack;
								
								public void EditPack() {
									clickOn(editpack);
								}
							
								@FindBy(xpath="//label[@for='abc4705-input']")
								private WebElement ifcondcheck;
								
								public void IfCheck() {
									clickOn(ifcondcheck);
								}
								
								@FindBy(xpath="(//span[@class='mat-radio-inner-circle'])[9]")
								private WebElement allrow;
								
								public void Allrow() {
									clickOn(allrow);
								}
								
								@FindBy(xpath="//i[@type='button']")
								private WebElement updatebtnplus;
								
								public void Updatebtnplus() {
									clickOn(updatebtnplus);
								}
								
								@FindBy(xpath="//button[@class='btn btn-success foot__btns ng-binding ng-star-inserted']")
								private WebElement updatebtn;
								
								public void Updatebtn() {
									clickOn(updatebtn);
								}
							
								@FindBy(xpath="//*[normalize-space()='newtestsuite']/..//*[@title='Delete']")
								private WebElement delete;
								
								public void Delete() {
									clickOn(delete);
								}
								
								@FindBy(xpath="(//i[@title='Close'])[1]")
								private WebElement close;
								
								public void Close() {
									clickOn(close);
								}
								
								@FindBy(xpath="//div[@title='demop']")
								private WebElement demopclick;
								
								public void DemopClick() {
									clickOn(demopclick);
								}
								
								@FindBy(xpath="//label[@for='abc4656-input']")
								private WebElement apptestcheck;
								
								public void AppTestCheck() {
									clickOn(apptestcheck);
								}
								
								@FindBy(xpath="//*[normalize-space()='newtestsuite']/..//*[@title='copy']")
								private WebElement tscopy;
								
								public void TSCopy() {
									clickOn(tscopy);
								}
								
								@FindBy(xpath="//div[@title='newtestpackmul']")
								private WebElement newtestpack;
								
								public void NewTp() {
									clickOn(newtestpack);
								}
								
								@FindBy(xpath="//button[@class='btn btn-danger foot__btns']")
								private WebElement cancel;
								
								public void Cancel() {
									clickOn(cancel);
								}
							
							


}
