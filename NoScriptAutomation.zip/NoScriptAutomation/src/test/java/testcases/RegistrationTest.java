package testcases;

import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.RegistrationPage;

public class RegistrationTest extends BaseTest1{
	@DataProvider(name="noskriptdata")
	public Object[][] noskriptdata() throws IOException {
		JsonObject jsonObject = BaseUtils.getTestData();
		JsonObject appData = jsonObject.getAsJsonObject("registration");
		Object[][] testData = new Object[1][14];
		
		testData[0][0] = appData.get("validpassword").getAsString();
		testData[0][1] = appData.get("Fullnameshort").getAsString();
		testData[0][2] = appData.get("Fullnamelong").getAsString();
		testData[0][3] = appData.get("validemail").getAsString();
		testData[0][4] = appData.get("Fullnamespace").getAsString();
		testData[0][5] = appData.get("FullnameSpecialChar").getAsString();
		testData[0][6] = appData.get("FullnameStartSpace").getAsString();
		testData[0][7] = appData.get("FullnameNumber").getAsString();
		testData[0][8] = appData.get("validuname").getAsString();
		testData[0][9] = appData.get("existinguname").getAsString();
		testData[0][10] = appData.get("existingemail").getAsString();
		testData[0][11] = appData.get("ValidFullName").getAsString();
		testData[0][12] = appData.get("usernameendspace").getAsString();
		testData[0][13] = appData.get("validManager").getAsString();
		
		return testData;
		}
	@Test(priority=0,dataProvider="noskriptdata")
	public void RegistrationTCNew(String validpassword,String fullnameshort,String fullnamelong,String validemail, String fullnamespace, String fullnamespecial, String fullnamestartspace, String fullnamenumber, String validuname, String existuname, String existemail, String validname,String unameendspace, String validmngr) throws InterruptedException {
		RegistrationPage r1=new RegistrationPage(driver);
		

		Thread.sleep(2000);
		r1.Acceptclick();
		
		r1.SignInClick();
		
		r1.SignUpPage();
		Thread.sleep(10000);
		
		//Full name space
		
		r1.fullname(fullnamespace);
		r1.EnterEmail(validemail);
		r1.username(validuname);
		r1.pass(validpassword);
		r1.conpass(validpassword);
		//r1.UserType();
		//r1.NewUser();
		Thread.sleep(2000);
		//r1.captcha();
		Thread.sleep(2000);
		r1.check1();
		Thread.sleep(2000);
		r1.check2();
		Thread.sleep(2000);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Fullname short
		
		r1.ClearAndEnterFullName(fullnameshort);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Fullname long
		
		r1.ClearAndEnterFullName(fullnamelong);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Full name starting with space
		
		r1.ClearAndEnterFullName(fullnamespace);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Fullname special
		
		r1.ClearAndEnterFullName(fullnamespecial);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Fullname number
		
		r1.ClearAndEnterFullName(fullnamenumber);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Invalid email
		
		r1.ClearAndEnterFullName(validname);
		r1.ClearAndEnterEmail(validname);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Existing email
		
		
		r1.ClearAndEnterEmail(existemail);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//User name only space
		
		
		r1.ClearAndEnterEmail(validemail);
		r1.ClearAndEnterUname(fullnamespace);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//User name short
		
		
		
		r1.ClearAndEnterUname(fullnameshort);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//User name long
		
		
		r1.ClearAndEnterUname(fullnamelong);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//User name with number
		
		
		r1.ClearAndEnterUname(fullnamenumber);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//User name with special character
		
		
		r1.ClearAndEnterUname(fullnamespecial);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//User name starting with space
		
		
		r1.ClearAndEnterUname(fullnamestartspace);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//User name end with space
		
		
		r1.ClearAndEnterUname(unameendspace);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Existing user name
		
		
		r1.ClearAndEnterUname(existuname);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Invalid password
		
		
		r1.ClearAndEnterUname(validuname);
		r1.ClearAndEnterpass(fullnameshort);
		r1.ClearAndEnterconpass(fullnameshort);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Password missmatch
		
		
		
		
		r1.ClearAndEnterpass(fullnamenumber);
		r1.ClearAndEnterconpass(fullnamespecial);
		r1.submit();
		
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Successful user registration with project type new
		
		
		r1.ClearAndEnterpass(validpassword);
		r1.ClearAndEnterconpass(validpassword);
		r1.submit();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
	}
		
		//Choosing project type as existing
	
		@Test(priority=1,dataProvider="noskriptdata")
		public void RegistrationTCExist(String validpassword,String fullnameshort,String fullnamelong,String validemail, String fullnamespace, String fullnamespecial, String fullnamestartspace, String fullnamenumber, String validuname, String existuname, String existemail, String validname,String unameendspace, String validmngr) throws InterruptedException {	
			RegistrationPage r2=new RegistrationPage(driver);
			
		//Check if manager name is varified or not
//			r2.Acceptclick();
//			
//			r2.SignInClick();
			
			r2.SignUpPage();
			Thread.sleep(10000);
		
		
			r2.fullname(validname);
			r2.EnterEmail(validemail);
			r2.username(validuname);
			r2.pass(validpassword);
			r2.conpass(validpassword);
			r2.UserType();
			r2.ExistingUser();
			r2.ManagerUname(fullnamespace);
			r2.captcha();
			r2.check1();
			r2.check2();
			r2.submit();
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
		
		//Check if the manager name is entered or not
			
			r2.ManagerUname(fullnamespace);
			r2.Verify();
			r2.submit();
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
		
		//Manager not valid name with space
			
			r2.ClearAndEnterManager(validname);
			r2.Verify();
			r2.submit();
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
		
		//Manager verified and successful registration
			
			r2.ClearAndEnterManager(validmngr);
			r2.Verify();
			r2.submit();
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
}
}
