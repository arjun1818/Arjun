package Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import Base.DriverUtils;

public class TestComponentPage extends DriverUtils{

	
	WebDriver driver;
	 public TestComponentPage(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	@FindBy(xpath="(//span[@class='mat-button-wrapper'])[3]")
	private WebElement Flow;
	 
	@FindBy(xpath="//button[@routerlink='/flow/test-component']")
	private WebElement TestComponent;
	
	@FindBy(xpath="(//div[@class='items'])[2]")
	private WebElement AppTest;
	
	@FindBy(xpath="//*[normalize-space()='IfCondition']/..//*[@title='Edit']")
	private WebElement Edit;
	
	@FindBy(xpath="//div[contains(@class,'mat-select-arrow-wrapper ng-tns-c98-13')]")
	private WebElement TechSelect;
	
	@FindBy(xpath="(//span[@class='mat-option-text'])[1]")
	private WebElement ChooseTech;
	
	@FindBy(xpath="//div[contains(@class,'mat-select-arrow ng-tns-c98-14')]")
	private WebElement Page;
	
	@FindBy(xpath="//mat-option[@id='mat-option-13']")
	private WebElement PageSelect;
	
	@FindBy(xpath="//i[@title='Delete']")
	private WebElement DeleteRadio;
	
		@FindBy(xpath="//div[@id='cdk-drop-list-1']")
	private WebElement DropLocation;
	
		@FindBy(xpath="//button[@class='btn btn-primary']")
		private WebElement New;
		
		public void NewComp() {
			clickOn(New);
		}
		
		@FindBy(xpath="//button[@class='btn btn-success foot__btns ng-star-inserted']")
		private WebElement updatetechdrop;
		
		public void UpdateTechDrop() {
			clickOn(updatetechdrop);
		}
		
		@FindBy(xpath="//div[@class='mat-select-value ng-tns-c98-25']")
		private WebElement updatepagedrop;
		
		public void UpdatePageDrop() {
			clickOn(updatepagedrop);
		}
		
		@FindBy(xpath="(//mat-option[@role='option'])[3]")
		private WebElement updatechooseif;
		
		public void UpdateChooseIf() {
			clickOn(updatechooseif);
		}

		 @FindBy(xpath="//input[@placeholder='Name']")
			private WebElement CompName;
			
			 public void NameComp(String compname) {
				 
					sendtext(CompName,compname);
			}
	
			 @FindBy(xpath="//button[@class='btn btn-success foot__btns ng-star-inserted']")
				private WebElement save;
				
				public void Save() {
					clickOn(save);
				}
				
				@FindBy(xpath="//*[normalize-space()='IsLogoPresent']/..//*[@title='Delete']")
				private WebElement delislog;
				
				public void DelIsLog() {
					clickOn(delislog);
				}
				
				public void ClearAndEnterCompName(String clearcomp) {
					 CompName.clear();
					 sendtext(CompName,clearcomp);
				}
	

	

	public WebElement getDropLocation() {
		return DropLocation;
	}
	
	@FindBy(xpath="//div[@title='Radio']")
	private WebElement DD1;
	
	public WebElement getDD1() {
		return DD1;
	}

	
	@FindBy(xpath="//div[@title='Confirm']")
	private WebElement DD2;
	
	
	
	public WebElement getDD2() {
		return DD2;
		
	}
	

	
	@FindBy(xpath="//div[@title='Typecountry']")
	private WebElement DD4;
	
	public WebElement getDD4() {
		return DD4;
	}
	@FindBy(xpath="//div[@title='AlertCnacel']")
	private WebElement DD5;
	
	public WebElement getDD5() {
		return DD5;
	}
	@FindBy(xpath="//div[@title='IsAlertPresent']")
	private WebElement DD6;
	
	public WebElement getDD6() {
		return DD6;
	}
	@FindBy(xpath="//div[@title='SuggestionClass']")
	private WebElement DD7;
	
	public WebElement getDD7() {
		return DD7;
	}
	@FindBy(xpath="//div[@title='WrongAlertText']")
	private WebElement DD8;
	
	public WebElement getDD8() {
		return DD8;
		
	}
	
	@FindBy(xpath="//div[@title='IsLogoPresent']")
	private WebElement DD9;
	
	public WebElement getDD9() {
		return DD9;
		
	}
	
	@FindBy(xpath="(//i[@title='Delete'])[3]")
	private WebElement Del;
	
	public void DelCountry() {
		clickOn(Del);
	}
	
	@FindBy(xpath="(//i[@class='fa fa-plus fa-xs'])[2]")
	private WebElement IfAdd;
	
	public void AddIf() {
		clickOn(IfAdd);
	}
	
	@FindBy(xpath="//i[@class='fa fa-close']")
	private WebElement ifclose;
	
	public void IfClose() {
		clickOn(ifclose);
	}
	
	@FindBy(xpath="(//td[@class='col-xs ng-star-inserted'])[2]")
	private WebElement DD10;
	
	public WebElement getDD10() {
		return DD10;
	}
	@FindBy(xpath="//div[@class='label-action-note ng-star-inserted']")
	private WebElement Drop2;
	
	public WebElement DropLocation2() {
		return Drop2;
	}
	
	@FindBy(xpath="//button[@id='button-basic']")
	private WebElement ifdrop;
	
	public void dropif() {
		clickOn(ifdrop);
	}
	
	@FindBy(xpath="(//span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[1]")
	private WebElement ifelsecheck;
	
	public void checkifelse() {
		clickOn(ifelsecheck);
	}
	
	@FindBy(xpath="(//span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[2]")
	private WebElement elsecheck;
	
	public void checkelse() {
		clickOn(elsecheck);
	}
	
	@FindBy(xpath="//button[@class='ifElseBtn ng-star-inserted']")
	private WebElement ifelseplus;
	
	public void elseplus() {
		clickOn(ifelseplus);
	}
	
	@FindBy(xpath="(//button[@class='ifElseBtn ng-star-inserted'])[2]")
	private WebElement ifelseplusclose;
	
	public void elseplusclose() {
		clickOn(ifelseplusclose);
	}
	
	
	@FindBy(xpath="//button[@class='btn btn-success foot__btns ng-star-inserted']")
	private WebElement UpdateButton;
	
	public void Update() {
		clickOn(UpdateButton);
	}
	
	@FindBy(xpath="//*[normalize-space()='NewTestComponent']/..//*[@title='Delete']")
	private WebElement delcomp;
	
	public void DelCopm() {
		clickOn(delcomp);
	}
	
	@FindBy(xpath="//button[@color='primary']")
	private WebElement delcompyes;
	
	public void DelCopmYes() {
		clickOn(delcompyes);
	}
	

	public void Delete() {
		clickOn(DeleteRadio);
	}
	
	public void FlowClick() {
	clickOn(Flow);
}
	 public void TestComp() {
			clickOn(TestComponent);
			}
	 public void AppTestClick() {
		 clickOn(AppTest);
		 
	 }
     public void EditClick() {
		 clickOn(Edit);
	 }
	 public void Technology() {
		 clickOn(TechSelect);
	 }
	 public void TechChoose() {
		 clickOn(ChooseTech);
	 }
	 public void PageField() {
		 clickOn(Page);
	 }
	 public void IfConditionSelect() {
		 clickOn(PageSelect);
	 }


	
// Test component view pom
	 
	 
	 @FindBy(xpath="(//i[@title='View'])[1]")
		private WebElement view;
		
		public void View() {
			clickOn(view);
		}
		
		 @FindBy(xpath="//mat-icon[@role='img']")
			private WebElement ifpresent;
			
			public void IfPresent() {
				clickOn(ifpresent);
			}

			 @FindBy(xpath="(//i[@class='fa fa-puzzle-piece'])[1]")
				private WebElement radiopresent;
				
				public void RadioPresent() {
					clickOn(radiopresent);
				}
				
				 @FindBy(xpath="(//i[@title='Copy'])[1]")
					private WebElement copy;
					
					public void Copy() {
						clickOn(copy);
					}
					
				
					@FindBy(xpath="//input[@placeholder='Name']")
					private WebElement copyname;
					
					 public void CopyName(String copyname) {
						 
							sendtext(CompName,copyname);
					}
					 
					 //Pom WebServices
					
					 @FindBy(xpath="(//span[@class='mat-option-text'])[2]")
						private WebElement chooseapi;
						
						public void ChooseApi() {
							clickOn(chooseapi);
						}
						
						 @FindBy(xpath="//mat-option[@role='option']")
							private WebElement pageapi;
							
							public void PageApi() {
								clickOn(pageapi);
							}
							
							@FindBy(xpath="//div[@title='DeleteExecute']")
							private WebElement api1;
							
							public WebElement getapi1() {
								return api1;
								
							}
							
							@FindBy(xpath="//div[@title='VarifyGetList']")
							private WebElement api2;
							
							public WebElement getapi2() {
								return api2;
								
							}
							
							@FindBy(xpath="//div[@title='VArifyNode']")
							private WebElement api3;
							
							public WebElement getapi3() {
								return api3;
								
							}
							
							@FindBy(xpath="//div[@title='Patchexecute']")
							private WebElement api4;
							
							public WebElement getapi4() {
								return api4;
								
							}
							
							@FindBy(xpath="//div[@title='PostExecute']")
							private WebElement api5;
							
							public WebElement getapi5() {
								return api5;
								
							}

							 @FindBy(xpath="//*[normalize-space()='newcomponent']/..//*[@title='Edit']")
								private WebElement editnewcomponentpage;
								
								public void Edit2() {
									clickOn(editnewcomponentpage);
								}
								
								@FindBy(xpath="//*[normalize-space()='newcomponent']/..//*[@title='Delete']")
								private WebElement deletenewcomponentpage;
								
								public void Delete2() {
									clickOn(deletenewcomponentpage);
								}
								
								 @FindBy(xpath="//*[normalize-space()='newcompapi']/..//*[@title='Edit']")
									private WebElement editnewcomponentpageapi;
									
									public void Editapi() {
										clickOn(editnewcomponentpageapi);
									}
									
									@FindBy(xpath="//*[normalize-space()='newcompapi']/..//*[@title='Delete']")
									private WebElement deletenewcomponentpageapi;
									
									public void Deleteapi() {
										clickOn(deletenewcomponentpage);
									}
									
									 @FindBy(xpath="//*[normalize-space()='newcompmob']/..//*[@title='Edit']")
										private WebElement editnewcomponentpagemob;
										
										public void Editmob() {
											clickOn(editnewcomponentpagemob);
										}
										
										@FindBy(xpath="//*[normalize-space()='newcompmob']/..//*[@title='Delete']")
										private WebElement deletenewcomponentpagemob;
										
										public void Deletemob() {
											clickOn(deletenewcomponentpagemob);
										}
								
								//Mobile
								
								 @FindBy(xpath="(//span[@class='mat-option-text'])[4]")
									private WebElement choosemob;
									
									public void ChooseMob() {
										clickOn(choosemob);
									}
									@FindBy(xpath="//div[@title='CheckBox']")
									private WebElement Mob1;
									
									public WebElement getMob1() {
										return Mob1;
									}
									@FindBy(xpath="//div[@title='CountryType']")
									private WebElement Mob2;
									
									public WebElement getMob2() {
										return Mob2;
									}
								 
							
				



}


