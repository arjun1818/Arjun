package Base;
 
import java.io.File;
 
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
 
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
 
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import Utilities.FileIo;
import io.cucumber.core.internal.com.fasterxml.jackson.core.type.TypeReference;
import io.cucumber.core.internal.com.fasterxml.jackson.databind.ObjectMapper;
 
public class BaseTest1 extends DriverUtils {

	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;
	public static Properties SERV_PROP_FILE;

	//	@BeforeMethod
//	public void setup()
//	{
//		
//		driver=invokebrowser();
//		openBrowser("app_Url");
//		
//	}
	@BeforeSuite
	public void loadData() {
		BaseUtils.loadData();
	}

	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser();
	}

	//	 @AfterTest
//	    public  void tearDownDriver() {
//	        driver.close();  // close the default window
//	        driver.quit();  // close the session
//	    } 
	public BaseTest1() {
		SERV_PROP_FILE = FileIo.initProperties();
	}
//	public List<HashMap<String, String>> getJsonData(String jsonFilePath) throws IOException {
//		// convert json file content to json string
//		String jsonContent = FileUtils.readFileToString(new File(jsonFilePath),StandardCharsets.UTF_8);
//		ObjectMapper mapper = new ObjectMapper();
//		List<HashMap<String, String>> data = mapper.readValue(jsonContent,
//				new TypeReference<List<HashMap<String, String>>>() {
//				});
//		return data;
//	}
}


