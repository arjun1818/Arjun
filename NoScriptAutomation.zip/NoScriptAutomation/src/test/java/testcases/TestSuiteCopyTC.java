package testcases;

import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.ExecutePage;
import Pages.LoginPage;

public class TestSuiteCopyTC extends BaseTest1{
	
		@DataProvider(name="noskriptdata")
		public Object[][] noskriptdata() throws IOException {
			JsonObject jsonObject = BaseUtils.getTestData();
			JsonObject appData = jsonObject.getAsJsonObject("testsuitecrud");
			Object[][] testData = new Object[1][11];
			
			testData[0][0] = appData.get("Username").getAsString();
			testData[0][1] = appData.get("Password").getAsString();
			testData[0][2] = appData.get("TestSuiteName").getAsString();
			testData[0][3] = appData.get("TestPackName").getAsString();
			testData[0][4] = appData.get("TestPackName2").getAsString();
			testData[0][5] = appData.get("TSnamewithspace").getAsString();
			testData[0][6] = appData.get("TsNamewithspecialChar").getAsString();
			testData[0][7] = appData.get("TsNameShort").getAsString();
			testData[0][8] = appData.get("TSnameendingspace").getAsString();
			testData[0][9] = appData.get("TsNamewithspace").getAsString();
			testData[0][10] = appData.get("TestSuiteCopy").getAsString();
		
			return testData;
			}
		
		@Test(dataProvider="noskriptdata")
		public void Testsuitecopy(String uname, String pass, String Tsname, String Tpname, String Tpname1, String tsnames, String tsnamesp, String tsshort, String tsendsp, String tsstspace, String tscopy) throws InterruptedException {
			ExecutePage ep=new ExecutePage(driver);
			LoginPage l1=new LoginPage(driver);
			l1.Acceptclick();
			l1.SignInClick();
			l1.UnameEnter(uname);
			
			l1.Password1(pass);
			l1.SignInbtnclick();
			Thread.sleep(2000);
			ep.execute();
			
			
			ep.TSCopy();
			
			// Test Suite Name Already exist
			
			Thread.sleep(5000);
	        ep.ClearAndEnterTSname(Tsname);
			ep.Cloud();
			ep.CreateTestPack();
			Thread.sleep(2000);
			ep.AppSelect();
			Thread.sleep(2000);
			ep.AppTest();
			Thread.sleep(2000);
			
			//Test Pack Name Already Exist
			
			ep.TestPackName(Tpname);
			
			ep.AddButton();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			// New Test Pack Name
			
			ep.ClearAndEnterTPname(Tpname1);
			ep.TestCaseCheck();
			Thread.sleep(2000);
			ep.AddButton();
			Thread.sleep(2000);
			ep.TestPackClick();
			Thread.sleep(2000);
			ep.EnvSelect();
			Thread.sleep(2000);
			ep.Env();
			Thread.sleep(2000);
			ep.Browser();
			Thread.sleep(2000);
			ep.Save();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			//Test Suite Name Starting with special characters
			Thread.sleep(2000);
			
			ep.ClearAndEnterTSname(tsnames);
			ep.Save();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			//Test Suite Name with space
			
             
			Thread.sleep(2000);
			ep.ClearAndEnterTSname(tsnamesp);
			ep.Save();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			//Test Suite Name Short
			
			Thread.sleep(2000);
			ep.ClearAndEnterTSname(tsshort);
			ep.Save();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			//Test Suite Name with space at end
			Thread.sleep(2000);
			ep.ClearAndEnterTSname(tsendsp);
			ep.Save();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			//Test Suite Name with space at start
			Thread.sleep(2000);
			ep.ClearAndEnterTSname(tsstspace);
			ep.Save();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			//Copy Test Suite name
			Thread.sleep(2000);
			ep.ClearAndEnterTSname(tscopy);
			ep.Save();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			Thread.sleep(2000);
			ep.Save();
//			Thread.sleep(2000);
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
//			});
			Thread.sleep(5000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//*[normalize-space()='newtestsuitecopy']")).isDisplayed());
			});
			
		}


	}

