package Base;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
 
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
 
import com.google.gson.Gson;
import com.google.gson.JsonObject;
 
 
 
public class BaseUtils {
	
	private static JsonObject testData;
	private static String env;
	private static String url;
	final static String propFilePath = System.getProperty("user.dir")+"\\src\\test\\resources\\develop.properties";
	final static String envFilePath = System.getProperty("user.dir")+"\\src\\test\\java\\testdata\\environments.json";
	public static void loadData() {
		//load env
		Properties properties = new Properties();
        try {
			properties.load(new FileReader(propFilePath));
            env = properties.getProperty("app_env");
            //System.out.println(env);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //load url
        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader(envFilePath));
            JSONObject jsonObject = (JSONObject) obj;
            url = (String) jsonObject.get(env);
            //System.out.println(url);
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        //load test data
		try (FileReader reader = new FileReader(System.getProperty("user.dir") + "\\src\\test\\java\\testdata\\" + env +".json")) {
            Gson gson = new Gson();
            testData = gson.fromJson(reader, JsonObject.class);
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
 
	public static JsonObject getTestData() {
		return testData;
	}
 
	public static String getUrl() {
		//System.out.println(url);
		return url;
	}
 
}
 