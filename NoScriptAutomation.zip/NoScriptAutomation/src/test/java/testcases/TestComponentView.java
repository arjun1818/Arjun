package testcases;

import static org.testng.Assert.assertTrue;

import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.LoginPage;
import Pages.TestComponentPage;

public class TestComponentView extends BaseTest1{
	@DataProvider(name="noskriptdata")
	public Object[][] noskriptdata() throws IOException {
		JsonObject jsonObject = BaseUtils.getTestData();
		JsonObject appData = jsonObject.getAsJsonObject("testsuitecrud");
		Object[][] testData = new Object[1][2];
		
		testData[0][0] = appData.get("Username").getAsString();
		testData[0][1] = appData.get("Password").getAsString();
		
	return testData;
	}
	
	@Test(dataProvider="noskriptdata")
	public void Condition(String uname,String pass) throws InterruptedException {
		Actions action = new Actions(driver);
		TestComponentPage c1= new TestComponentPage(driver);
		LoginPage l1=new LoginPage(driver);
		
		l1.Acceptclick();
		Thread.sleep(2000);
		l1.SignInClick();
		Thread.sleep(2000);
		
		l1.UnameEnter(uname);
		Thread.sleep(2000);
		l1.Password1(pass);
		Thread.sleep(2000);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		
		//l1.ProjClick();
		
		c1.FlowClick();
		Thread.sleep(2000);
		c1.TestComp();
		Thread.sleep(2000);
		c1.AppTestClick();
		Thread.sleep(2000);
		c1.View();
		Thread.sleep(2000);
		String actualString = driver.findElement(By.xpath("(//div[@class='panel-heading'])[2]")).getText();
		assertTrue(actualString.contains("Test Component"));
	
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("//mat-icon[@role='img']")).isDisplayed());
//		});
		c1.IfPresent();
		c1.RadioPresent();
		Thread.sleep(2000);
		String actualString1 = driver.findElement(By.xpath("(//div[@class='long-text'])[10]")).getText();
		assertTrue(actualString1.contains("Radio"));
		
		
		
		
}
}
