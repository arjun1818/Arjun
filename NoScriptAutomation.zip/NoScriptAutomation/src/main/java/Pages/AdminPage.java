package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.DriverUtils;

public class AdminPage extends DriverUtils{
	 WebDriver driver;
	 public AdminPage(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	 @FindBy(xpath="//button[@class='btn btn-sm acceptcookies cookie__btncustom']")
		private WebElement Accept;
	@FindBy(xpath="(//a[@href='https://nsdev.azurewebsites.net/scriptless/beta/index.html'])[1]")
	private WebElement SignIn;
	@FindBy(xpath="//input[@id='username']")
	private WebElement Uname;
	@FindBy(xpath="//input[@id='password']")
	private WebElement Password;
	@FindBy(xpath="//input[@id='kc-login']")
	private WebElement signinbtn;
	@FindBy(xpath="(//div[contains(@class,'pro__name')])[1]")
	private WebElement ChooseProj;
	@FindBy(xpath="(//span[@class='mat-button-wrapper'])[6]")
	private WebElement Settings;
	@FindBy(xpath="//button[@routerlink='/admin/approve-users']")
	private WebElement UserApprove;
	@FindBy(xpath="//*[normalize-space()='Arjun M Mohan']/..//*[@title='Edit']")
	private WebElement EditUser;
	@FindBy(xpath="(//mat-select[@role='combobox'])[3]")
	private WebElement SelectPlatform;
	@FindBy(xpath="(//span[@class='mat-option-text'])[1]")
	private WebElement NoScript;
	@FindBy(xpath="(//option[contains(@class,'ng-star-inserted')])[1]")
	private WebElement Proj;
	@FindBy(xpath="(//button[@class='btn btn-default chooden-btn'])[1]")
	private WebElement SetBtn;
	@FindBy(xpath="//i[@class='fa fa-arrow-left']")
	private WebElement ReSetBtn;
	@FindBy(xpath="(//mat-select[@role='combobox'])[4]")
	private WebElement Role;
	@FindBy(xpath="(//span[@class='mat-option-text'])[4]")
	private WebElement SelectRole;
	@FindBy(xpath="(//span[@class='mat-button-wrapper'])[14]")
	private WebElement Cal;
	@FindBy(xpath="(//div[@class='mat-calendar-body-cell-content mat-focus-indicator'])[30]")
	private WebElement Date;
	@FindBy(xpath="//button[@class='btn btn-success foot__btns ng-binding ng-star-inserted']")
	private WebElement Approved;
	
	public void Acceptclick() {
		clickOn(Accept);
	}
		 public void SignInClick() {
				clickOn(SignIn);
				}
		
		 public void SignIn(String uname, String pass) {
			 sendtext(Uname,uname);
			 sendtext(Password,pass);
			 clickOn(signinbtn);
		 }
		 public void ProjClick() {
			 clickOn(ChooseProj);
		 }
		 public void settings() {
			 clickOn(Settings);
		 }
		 public void ApproveUser() {
			 clickOn(UserApprove);
		 }
		 public void UserEdit() {
			 clickOn(EditUser);
		 }
		 public void PlatformSelect() {
			 clickOn(SelectPlatform);
		 }
		 public void SelectNoScript() {
			 clickOn(NoScript);
		 }
		 public void ChProj() {
			 clickOn(Proj);
		 }
		 public void BtnSet() {
			 clickOn(SetBtn);
		 }
		 public void role() {
			 clickOn(Role);
		 }
		 public void SetRole() {
			 clickOn(SelectRole);
		 }
		 public void Callender() {
			 clickOn(Cal);
		 }
		 public void DateSelect() {
			 clickOn(Date);
		 }
		 
		 public void Approval() {
			 clickOn(Approved);
		 }
		 @FindBy(xpath="//button[contains(@class,'btn btn-success foot__btns ng-binding ng-star-inserted')]")
			private WebElement update;
			
			public void Update() {
				clickOn(update);
			}
			
			@FindBy(linkText=" USTProject ")
			private WebElement selectedproj;
			
			public void SelectedProj() {
				clickOn(selectedproj);
			}
			@FindBy(xpath="(//button[@class='btn btn-default chooden-btn'])[2]")
			private WebElement reset;
			
			public void Reset() {
				clickOn(reset);
			}
			@FindBy(xpath="//option[@value='0: Object']")
			private WebElement projdeselect;
			
			public void DeselectProj() {
				clickOn(projdeselect);
			}
			
			 @FindBy(xpath="//input[@id='mat-input-0']")
				private WebElement searchname;
				
				 public void SearchName(String search) {
					 
						sendtext(searchname,search);
			}
				 
				 @FindBy(xpath="//span[contains(@class,'mat-select-value-text ng-tns-c98-8 ng-star-inserted')]")
					private WebElement statusdrop;
					
					public void Statusdrop() {
						clickOn(statusdrop);
					}	 
					
					 
					 @FindBy(xpath="(//span[@class='mat-option-text'])[3]")
						private WebElement statusselect;
						
						public void StatusSelect() {
							clickOn(statusselect);
						}	
						
						 @FindBy(xpath="//i[@title='Edit']")
							private WebElement edituser1;
							
							public void EditUser1() {
								clickOn(edituser1);
							}	
							
							@FindBy(xpath="(//span[@class='mat-button-wrapper'])[9]")
							private WebElement adminlogout;
							
							public void AdminLogout() {
								clickOn(adminlogout);
							}	
							
							@FindBy(xpath="(//button[@role='menuitem'])[2]")
							private WebElement adminlogoutop;
							
							public void AdminLogoutOp() {
								clickOn(adminlogoutop);
							}	
							
					
			
		

}
