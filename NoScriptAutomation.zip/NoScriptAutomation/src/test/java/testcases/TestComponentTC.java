package testcases;

import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;

import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.LoginPage;
import Pages.TestComponentPage;

public class TestComponentTC extends BaseTest1{

	@DataProvider(name="noskriptdata")
	public Object[][] noskriptdata() throws IOException {
		JsonObject jsonObject = BaseUtils.getTestData();
		JsonObject appData = jsonObject.getAsJsonObject("testcomponentcrud");
		Object[][] testData = new Object[1][11];
		
		testData[0][0] = appData.get("Username").getAsString();
		testData[0][1] = appData.get("Password").getAsString();
		testData[0][2] = appData.get("CompNameExist").getAsString();
		testData[0][3] = appData.get("CompNameSpecial").getAsString();
		testData[0][4] = appData.get("CompNameSpace").getAsString();
		testData[0][5] = appData.get("CompNameStartSpace").getAsString();
		testData[0][6] = appData.get("CompNameEndSpace").getAsString();
		testData[0][7] = appData.get("CompShort").getAsString();
		testData[0][8] = appData.get("CompValidWeb").getAsString();
		testData[0][9] = appData.get("CompValidApi").getAsString();
		testData[0][10] = appData.get("CompValidMob").getAsString();
		
	return testData;
	}
	
	/*****************************************Web******************************************/
	
	@Test(priority=0,dataProvider="noskriptdata")
	public void TestComponentWeb(String uname,String pass, String a, String b, String c, String d, String e, String f, String g, String api, String mob) throws InterruptedException {
		
		TestComponentPage c1= new TestComponentPage(driver);
		LoginPage l1=new LoginPage(driver);
		Actions action = new Actions(driver);
		
		l1.Acceptclick();
		Thread.sleep(2000);
		l1.SignInClick();
		Thread.sleep(2000);
		
		l1.UnameEnter(uname);
		Thread.sleep(2000);
		l1.Password1(pass);
		Thread.sleep(2000);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		
		//l1.ProjClick();
		
		c1.FlowClick();
		Thread.sleep(2000);
		c1.TestComp();
		Thread.sleep(2000);
		c1.AppTestClick();
		Thread.sleep(2000);
		c1.NewComp();
		Thread.sleep(2000);
		
		// Without Selecting Technology
		
		c1.Save();
	
		//Test Component Name Null
		
		c1.Technology();
		Thread.sleep(2000);
		c1.TechChoose();
		Thread.sleep(2000);
		c1.PageField();
		Thread.sleep(2000);
		c1.IfConditionSelect();
		Thread.sleep(2000);
		
		
		
		

		
				
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='Radio']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='Confirm']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='Typecountry']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='AlertCnacel']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='IsAlertPresent']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='SuggestionClass']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='WrongAlertText']")).isDisplayed());
		});
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='IsLogoPresent']")).isDisplayed());
		});
		

		//Building a drag and drop action
		
//	

		
		
//		//Performing the drag and drop action
		
	Action dragAndDrop1 = action.clickAndHold( c1.getDD1())
		.moveToElement(c1.getDropLocation())
		.release( c1.getDropLocation())
		.build();
	
	

		
		dragAndDrop1.perform();
		
		
		
		
		
		Action dragAndDrop2 = action.clickAndHold( c1.getDD4())
				.moveToElement(c1.getDropLocation())
				.release( c1.getDropLocation())
				.build();

				//Performing the drag and drop action
				dragAndDrop2.perform();
				
				
				
			Action dragAndDrop3 = action.clickAndHold( c1.getDD2())
						.moveToElement(c1.getDropLocation())
						.release( c1.getDropLocation())
						.build();
		
						dragAndDrop3.perform();

						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});
						
	//Test Component Name Already Exist
						
						c1.NameComp(a);
						
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});	
						
	// Test Component Name with special characters	
						
						c1.ClearAndEnterCompName(b);
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});	
						
	// Test Component Name with space
						
						c1.ClearAndEnterCompName(c);
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});	
						
	// Test Component Name starting with space
						
						c1.ClearAndEnterCompName(d);
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});	
						
	// Test Component Name ending with space 
						
						c1.ClearAndEnterCompName(e);
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});
						
						
						
	// Test Component Name short
						
						c1.ClearAndEnterCompName(f);
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});	
						
	//Adding empty if condition 
						
						Thread.sleep(2000);
						c1.ClearAndEnterCompName(g);
						c1.AddIf();
						
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});
						
//Multiple empty if and if else 
						
						Thread.sleep(2000);
						c1.dropif();
						
						Thread.sleep(2000);
						c1.checkifelse();
						Thread.sleep(2000);
						c1.elseplus();
						Thread.sleep(2000);
						c1.checkelse();
						Thread.sleep(2000);
						c1.AddIf();
						Thread.sleep(2000);
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});
						c1.IfClose();
						
						//c1.AddIf();
						
						
						
    //Giving if condition without then			
						
						Thread.sleep(2000);
						Action dragAndDrop8= action.clickAndHold( c1.getDD9())
										.moveToElement(c1.getDropLocation())
										.release( c1.getDropLocation())
										.build();
						
										dragAndDrop8.perform();
						c1.Save();
						Thread.sleep(2000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});
	

						
			
						
			
			
			// Conditional steps without adding if condition			
										
						Thread.sleep(2000);
						c1.IfClose();
						c1.Save();
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});
						
			
						
						
			//Successfull Component Creation
						
						Thread.sleep(2000);
						c1.DelIsLog();
						c1.Save();
						Thread.sleep(2000);
//						SoftAssertions.assertSoftly(softAssertions -> {
//							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
//						});
						
				//Update Already Existing Component
						
						c1.Edit2();
//						Thread.sleep(4000);
//						c1.Technology();
//					   
//						Thread.sleep(4000);
//						c1.TechChoose();
//						Thread.sleep(4000);
//						c1.PageField();
//						Thread.sleep(2000);
//				    	c1.IfConditionSelect();
						
						
//						
//						Thread.sleep(2000);
//						Action dragAndDrop5= action.clickAndHold( c1.getDD5())
//										.moveToElement(c1.DropLocation2())
//										.release( c1.DropLocation2())
//										.build();
//						
//										dragAndDrop5.perform();
//						Thread.sleep(2000);
						
						
						c1.Update();
//						SoftAssertions.assertSoftly(softAssertions -> {
//							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
//						});
			
															
										
            //Deleting created component
										
						Thread.sleep(2000);
						c1.Delete2();
						Thread.sleep(2000);
						c1.DelCopmYes();
						Thread.sleep(3000);
						SoftAssertions.assertSoftly(softAssertions -> {
							softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
						});
										
			
	}
	
	/**********************************Web Services************************************************/
				
	@Test(priority=1,dataProvider="noskriptdata")
	public void TestComponentApi(String uname1,String pass1, String a, String b, String c, String d, String e, String f, String g, String api, String mob) throws InterruptedException {
		TestComponentPage c2=new TestComponentPage(driver);
		LoginPage l1=new LoginPage(driver);
		Actions action = new Actions(driver);
		l1.Acceptclick();
		Thread.sleep(2000);
		l1.SignInClick();
		Thread.sleep(2000);
		
		l1.UnameEnter(uname1);
		Thread.sleep(2000);
		l1.Password1(pass1);
		Thread.sleep(2000);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		
		
		c2.FlowClick();
		Thread.sleep(2000);
		c2.TestComp();
		Thread.sleep(2000);
		c2.AppTestClick();
		Thread.sleep(2000);
		c2.NewComp();
		Thread.sleep(2000);
		
		//Test Component Name Already Exist
		
		c2.NameComp(a);
		
		c2.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name with special characters	
		
		c2.ClearAndEnterCompName(b);
		c2.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name with space
		
		c2.ClearAndEnterCompName(c);
		c2.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name starting with space
		
		c2.ClearAndEnterCompName(d);
		c2.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name ending with space 
		
		c2.ClearAndEnterCompName(e);
		c2.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		
// Test Component Name short
		
		c2.ClearAndEnterCompName(f);
		c2.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test component Name Valid
		c2.ClearAndEnterCompName(api);
		c2.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
		
		c2.Technology();
		Thread.sleep(2000);
		c2.ChooseApi();
		Thread.sleep(2000);
		c2.PageField();
		Thread.sleep(2000);
		c2.PageApi();
		Thread.sleep(2000);
		
		//Drag and drop operation
		
		     Action dragAndDropapi1= action.clickAndHold( c2.getapi1())
			.moveToElement(c2.getDropLocation())
			.release( c2.getDropLocation())
			.build();
			 dragAndDropapi1.perform();
			 
			 Thread.sleep(2000);
			 
			 //Atleast one condition needed in if
			 
			 c2.AddIf();
			 c2.Save();
			 Thread.sleep(2000);
			 SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
				});
			 
			 //Checking and unchecking elseif and else checkbox
			 
			 c2.dropif();
			 Thread.sleep(2000);
			 
			 c2.checkifelse();
			 c2.checkelse();
			 Thread.sleep(2000);

			 Action dragAndDropapi4= action.clickAndHold( c2.getapi4())
						.moveToElement(c2.getDropLocation())
						.release( c2.getDropLocation())
						.build();
						 dragAndDropapi4.perform();
			 c2.elseplus();
			 c2.elseplusclose();
			 c2.dropif();
			 c2.checkifelse();
			 c2.checkelse();
			 c2.Save();
			 Thread.sleep(2000);
			 SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
				});
			 
			 // Drag and drop operation
			 
			 Action dragAndDropapi2= action.clickAndHold( c2.getapi2())
						.moveToElement(c2.getDropLocation())
						.release( c2.getDropLocation())
						.build();
						 dragAndDropapi2.perform();
			
						 Action dragAndDropapi3= action.clickAndHold( c2.getapi3())
									.moveToElement(c2.getDropLocation())
									.release( c2.getDropLocation())
									.build();
									 dragAndDropapi3.perform();
						 
			 
						
			
												 Action dragAndDropapi5= action.clickAndHold( c2.getapi5())
															.moveToElement(c2.getDropLocation())
															.release( c2.getDropLocation())
															.build();
															 dragAndDropapi5.perform();
															 
															 c2.IfClose();
															 c2.Save();
															 Thread.sleep(2000);
//															 SoftAssertions.assertSoftly(softAssertions -> {
//																	softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
//																});
				
				//Updating created component		
															 
				c2.Editapi();
				Thread.sleep(2000);
//				c2.Technology();
//				c2.ChooseApi();
//				c2.PageField();
//				c2.PageApi();
				//dragAndDropapi5.perform();
				
				
				
				 c2.Update();
				 Thread.sleep(2000);
				 SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
					});
						
				 
				 //Deleting created component
				 
				 c2.Deleteapi();
				 Thread.sleep(2000);
				 c2.DelCopmYes();
				 Thread.sleep(2000);
				 SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
					});
				 
																
											
		
	}
	
	/********************************************Mobile************************************************/
	
	@Test(priority=2,dataProvider="noskriptdata")
	public void TestComponentMobile(String uname2,String pass2, String a, String b, String c, String d, String e, String f, String g, String api, String mob) throws InterruptedException {
		TestComponentPage c3=new TestComponentPage(driver);
		LoginPage l2=new LoginPage(driver);
		Actions action = new Actions(driver);
		l2.Acceptclick();
	    Thread.sleep(2000);
		l2.SignInClick();
		Thread.sleep(2000);
		
		l2.UnameEnter(uname2);
		Thread.sleep(2000);
		l2.Password1(pass2);
		Thread.sleep(2000);
		
		l2.SignInbtnclick();
	    Thread.sleep(2000);
		
		
		c3.FlowClick();
		Thread.sleep(2000);
		c3.TestComp();
	    Thread.sleep(2000);
		c3.AppTestClick();
		Thread.sleep(2000);
		c3.NewComp();
		Thread.sleep(2000);
		
		//Test Component Name Already Exist
		
		c3.NameComp(a);
		
		c3.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name with special characters	
		
		c3.ClearAndEnterCompName(b);
		c3.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name with space
		
		c3.ClearAndEnterCompName(c);
		c3.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name starting with space
		
		c3.ClearAndEnterCompName(d);
		c3.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test Component Name ending with space 
		
		c3.ClearAndEnterCompName(e);
		c3.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		
// Test Component Name short
		
		c3.ClearAndEnterCompName(f);
		c3.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
// Test component Name Valid
		c3.ClearAndEnterCompName(mob);
		c3.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});	
		
		
		c3.Technology();
		Thread.sleep(2000);
		c3.ChooseMob();
		Thread.sleep(2000);
		c3.PageField();
		Thread.sleep(2000);
		c3.PageApi();
		Thread.sleep(2000);
		
		//Drag and drop operation
		
		     Action dragAndDropmob1= action.clickAndHold( c3.getDD1())
			.moveToElement(c3.getDropLocation())
			.release( c3.getDropLocation())
			.build();
			 dragAndDropmob1.perform();
			 
			 Thread.sleep(2000);
			 
			 //Atleast one condition needed in if
			 
			 c3.AddIf();
			 c3.Save();
			 Thread.sleep(2000);
			 SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
				});
			 
			 //Checking and unchecking elseif and else checkbox
			 
			 c3.dropif();
			 Thread.sleep(2000);
			 
			 c3.checkifelse();
			 c3.checkelse();
			 Thread.sleep(2000);

			 Action dragAndDropmob2= action.clickAndHold( c3.getMob2())
						.moveToElement(c3.getDropLocation())
						.release( c3.getDropLocation())
						.build();
						 dragAndDropmob2.perform();
			 c3.elseplus();
			 c3.elseplusclose();
			 c3.dropif();
			 c3.checkifelse();
			 c3.checkelse();
			 c3.Save();
			 Thread.sleep(2000);
			 SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
				});
			 
			 Action dragAndDropmob3= action.clickAndHold( c3.getMob1())
						.moveToElement(c3.getDropLocation())
						.release( c3.getDropLocation())
						.build();
						 
			 //Successful Component creation
			c3.IfClose();
			c3.Save();
//			Thread.sleep(2000);
//			SoftAssertions.assertSoftly(softAssertions -> {
//				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
//				});
				
				//Updating created component		
															 
				c3.Editmob();
				Thread.sleep(4000);
//				c3.Technology();
//				c3.ChooseMob();
//				c3.PageField();
//				c3.PageApi();
//				dragAndDropmob3.perform();
				
				
				
				c3.Update();
				 Thread.sleep(2000);
				 SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
					});
						
				 
				 //Deleting created component
				 
				 c3.Deletemob();
				 Thread.sleep(2000);
				 c3.DelCopmYes();
				 Thread.sleep(2000);
				 SoftAssertions.assertSoftly(softAssertions -> {
						softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
					});
				 
																
											
		
	}


}

