package Pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseTest1;

public class Design extends BaseTest1 {
	WebDriver driver;
	 public Design(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	 @FindBy(xpath="(//div[@class='pro__name'])[2]")
		private WebElement SelectProj;
		
		public void ProjectSelect() {
			clickOn(SelectProj);
		}
	 
	 @FindBy(xpath="(//span[@class='mat-button-wrapper'])[2]")
		private WebElement DesignClick;
		
		public void ClickDesign() {
			clickOn(DesignClick);
		}
		
		
		
		public void Drop() {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.querySelector('label.box-title',':before').click();");
			
		}
		
		 @FindBy(xpath="(//li[@title='Double click to edit Testpage1'])[1]")
			private WebElement TestPage1;
			
			public void TestPage1select() {
				clickOn(TestPage1);
			}
		
		@FindBy(xpath="//button[@class='btn btn-primary']")
		private WebElement New;
		
		public void NewStep() {
			clickOn(New);
		}
		
		@FindBy(xpath="//input[@id='stepName']")
		private WebElement StepName;
		
		 public void NamePage(String sname) {
			 
				sendtext(StepName,sname);
		}
		 
		 @FindBy(xpath="//div[@id='mat-select-value-3']")
			private WebElement Activity;
			
		 public void DropActivity() {
				clickOn(Activity);
			}
		 
		 @FindBy(xpath="(//span[@class='mat-option-text'])[4]")
			private WebElement Assertion;
			
		 public void SelectAssertion() {
				clickOn(Assertion);
			}
		 
		 @FindBy(xpath="(//span[@class='mat-radio-label-content'])[1]")
			private WebElement ConditionYes;
			
		 public void YesCondition() {
				clickOn(ConditionYes);
			}
		 
		 @FindBy(xpath="//input[@id='assertionName']")
			private WebElement AssertionName;
			
			 public void AssertName(String Assname) {
				 
					sendtext(AssertionName,Assname);
			}
			 
			 @FindBy(xpath="//div[@id='mat-select-value-7']")
				private WebElement SelectAss;
				
			 public void AssertSelect() {
					clickOn(SelectAss);
				}
			 
			 @FindBy(xpath="(//span[@class='mat-option-text'])[5]")
				private WebElement DoesTextContain;
				
			 public void DoesText() {
					clickOn(DoesTextContain);
				}
			 
			 @FindBy(xpath="//div[@id='mat-select-value-11']")
				private WebElement LocatorDrop;
				
			 public void LocType() {
					clickOn(LocatorDrop);
				}
			 
			 @FindBy(xpath="(//span[@class='mat-option-text'])[1]")
				private WebElement IdSelect;
				
			 public void SelectId() {
					clickOn(IdSelect);
				}
			 
			 @FindBy(xpath="//input[@placeholder='Locator Value']")
				private WebElement LocatorValue;
				
				 public void LocatorVal(String LocValue) {
					 
						sendtext(LocatorValue,LocValue);
				}
				 
				 @FindBy(xpath="//input[@id='input-0']")
					private WebElement TestData;
					
					 public void DataTest(String testdata) {
						 
							sendtext(TestData,testdata);
					}

					 @FindBy(xpath="//button[@class='btn btn-success foot__btns ng-binding ng-star-inserted']")
						private WebElement Save;
						
					 public void SaveChanges() {
							clickOn(Save);
						}
					 
					 @FindBy(xpath="(//i[@title='Edit'])[1]")
						private WebElement Edit;
						
					 public void EditTest() {
							clickOn(Edit);
						}
					 
					 @FindBy(xpath="//button[@class='btn btn-load add__rule']")
						private WebElement Addrule;
						
					 public void AddRule() {
							clickOn(Addrule);
						}
					 
					 @FindBy(xpath="//input[@id='SrcString']")
						private WebElement SrcString;
						
						 public void StringSrc(String sstring) {
							 
								sendtext(SrcString,sstring);
						}
						 
						 @FindBy(xpath="(//span[@class='mat-checkbox-inner-container'])[1]")
							private WebElement rmvspcl;
							
						 public void RemoveCheck() {
								clickOn(rmvspcl);
							}
						 @FindBy(xpath="//button[@class='btn btn-success foot__btns ng-binding']")
							private WebElement Save2;
							
						 public void SaveRule() {
								clickOn(Save2);
							}
						 @FindBy(xpath="//button[@class='btn btn-success foot__btns ng-binding ng-star-inserted']")
							private WebElement update;
							
						 public void Update() {
								clickOn(update);
							}
						 
						 @FindBy(xpath="(//i[@class='fa fa-trash ico__color tableico ng-star-inserted'])[1]")
							private WebElement delete;
							
						 public void Delete() {
								clickOn(delete);
							}
						 
						 @FindBy(xpath="//button[@class='mat-focus-indicator mat-raised-button mat-button-base mat-primary btnYes']")
							private WebElement yes;
							
						 public void Yes() {
								clickOn(yes);
							}
						 
}
