package testcases;

import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.ExecutePage;
import Pages.LoginPage;
import Pages.TestComponentPage;

public class TestSuiteTC extends BaseTest1{
	@DataProvider(name="noskriptdata")
	public Object[][] noskriptdata() throws IOException {
		JsonObject jsonObject = BaseUtils.getTestData();
		JsonObject appData = jsonObject.getAsJsonObject("testsuitecrud");
		Object[][] testData = new Object[1][12];
		
		testData[0][0] = appData.get("Username").getAsString();
		testData[0][1] = appData.get("Password").getAsString();
		testData[0][2] = appData.get("TestSuiteName").getAsString();
		testData[0][3] = appData.get("TestPackName").getAsString();
		testData[0][4] = appData.get("TsNamewithspace").getAsString();
		testData[0][5] = appData.get("TpNamewithspace").getAsString();
		testData[0][6] = appData.get("TsNamewithspecialChar").getAsString();
		testData[0][7] = appData.get("TpNamewithspecialChar").getAsString();
		testData[0][8] = appData.get("TsNameShort").getAsString();
		testData[0][9] = appData.get("TpNameshort").getAsString();
		testData[0][10] = appData.get("TestPackName1").getAsString();
		testData[0][11] = appData.get("TestPackNameMul").getAsString();
		
		return testData;
		}
	@Test(dataProvider="noskriptdata")
	public void CrudTestSuite(String uname, String pass, String tsname, String tpname, String tsnames, String tpnames, String tsnamesch, String tpnamesch, String tsshort, String tpshort, String tpname1, String tpnamemul) throws InterruptedException {
		ExecutePage ep= new ExecutePage(driver);
		LoginPage l1=new LoginPage(driver);
		TestComponentPage tcp=new TestComponentPage(driver);
		Thread.sleep(5000);
		//l1.Acceptclick();
		l1.SignInClick();
		l1.UnameEnter(uname);
		l1.Password1(pass);
		l1.SignInbtnclick();
		Thread.sleep(2000);
		ep.execute();
		
		//Without Test Suite Name
		
		ep.NewTestSuite();
		Thread.sleep(2000);
		ep.TestingSelect();
		Thread.sleep(2000);
		ep.RegressionTest();
		Thread.sleep(2000);
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Test Suite Name starting with space
		
		ep.ClearAndEnterTSname(tsnames);
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		// Test Suite name ending with space
		
		ep.ClearAndEnterTSname("test ");
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Test Suite Name starting with number 
		
		ep.ClearAndEnterTSname("1test");
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		//Test Suite Name with special character
		
		ep.ClearAndEnterTSname(tsnamesch);
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Test Suite Name short
		
		ep.ClearAndEnterTSname(tsshort);
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Valid Test Suite Name without creating test pack
		
		ep.ClearAndEnterTSname(tsname);
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		ep.ClearAndEnterTSname(tsname);
		
		ep.Cloud();
		ep.CreateTestPack();
		Thread.sleep(2000);
		ep.AppSelect();
		Thread.sleep(2000);
		ep.AppTest();
		Thread.sleep(2000);
		
		//Null Test Pack Name
		
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Test Pack Name Starting with Space
		
		ep.ClearAndEnterTPname(tpname);
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Test Pack Name with special character
		
		ep.ClearAndEnterTPname(tpnamesch);
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Test Pack Name Short
		
		ep.ClearAndEnterTPname(tpshort);
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Test pack name starting with numeber
		
		ep.ClearAndEnterTPname("2test");
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		//Test Pack Name Ending with space
		
		ep.ClearAndEnterTPname("test ");
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		
		//Valid Test Pack Name without selecting any test case
		
		ep.ClearAndEnterTPname(tpname);
		Thread.sleep(2000);
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		
		
		//Successful Test Suite creation
		
		ep.ClearAndEnterTPname(tpname);
		ep.TestCaseCheck();
		Thread.sleep(2000);
		ep.AddButton();
		Thread.sleep(2000);
		
		//Creation of test suite with multiple test packs
		
		//Adding test pack name same as previous test pack name
		ep.CreateTestPack();
		ep.AppSelect();
		Thread.sleep(2000);
		ep.AppTest();
		Thread.sleep(2000);
		ep.ClearAndEnterTPname(tpname);
		Thread.sleep(2000);
		ep.TestCaseCheck();
		Thread.sleep(2000);
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Successful creation of multiple test pack
		
		
		ep.ClearAndEnterTPname(tpnamemul);
		
		Thread.sleep(2000);
		ep.AddButton();
		Thread.sleep(4000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@title='newtestpackmul']")).isDisplayed());
		});
		
		
		ep.NewTp();
		Thread.sleep(2000);
		ep.EnvSelect();
		Thread.sleep(2000);
		ep.Env();
		Thread.sleep(2000);
		ep.Browser();
		Thread.sleep(2000);
		ep.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		Thread.sleep(3000);
		ep.TestPackClick();
		Thread.sleep(2000);
		ep.EnvSelect();
		Thread.sleep(2000);
		ep.Env();
		Thread.sleep(2000);
		ep.Browser();
		Thread.sleep(2000);
		ep.Save();
		
		
		
		
		
		
//		//Test Suite Already Exist
//		
//		ep.NewTestSuite();
//		Thread.sleep(2000);
//		ep.TestingSelect();
//		Thread.sleep(2000);
//		ep.RegressionTest();
//		Thread.sleep(2000);
//        ep.ClearAndEnterTSname(tsname);
//		
//		ep.Cloud();
//		ep.CreateTestPack();
//		Thread.sleep(2000);
//		ep.AppSelect();
//		Thread.sleep(2000);
//		ep.AppTest();
//		Thread.sleep(2000);
//		ep.ClearAndEnterTPname("testpackdemo");
//		ep.TestCaseCheck();
//		Thread.sleep(2000);
//		ep.AddButton();
//		Thread.sleep(2000);
//		ep.TestPackClick();
//		Thread.sleep(2000);
//		ep.EnvSelect();
//		Thread.sleep(2000);
//		ep.Env();
//		Thread.sleep(2000);
//		ep.Browser();
//		Thread.sleep(2000);
//		ep.Save();
//		Thread.sleep(2000);
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
//		});
//		Thread.sleep(2000);
//		ep.Close();
		
		
		
		
		
		//Updation of Test Suite
		
		ep.Update();
		
		//Test Pack Already Exist
		Thread.sleep(2000);
		ep.CreateTestPack();
		Thread.sleep(2000);
		ep.AppSelect();
		Thread.sleep(2000);
		ep.AppTest();
		Thread.sleep(2000);
		ep.ClearAndEnterTPname(tpname);
		
		ep.IfCheck();
		Thread.sleep(2000);
		ep.AddButton();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//Successfull Updation
		
		Thread.sleep(2000);
		ep.ClearAndEnterTPname(tpname1);
//		Thread.sleep(2000);
//		ep.AppTestCheck();
//		Thread.sleep(2000);
//		ep.IfCheck();
		Thread.sleep(2000);
		ep.AddButton();
		Thread.sleep(2000);
//		ep.Cancel();
		ep.DemopClick();
		Thread.sleep(2000);
		ep.EnvSelect();
		Thread.sleep(2000);
		ep.Env();
		Thread.sleep(2000);
		ep.Browser();
		Thread.sleep(2000);
		ep.Updatebtn();
		Thread.sleep(2000);
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
//		});
		
		
		
		
		
		
		//Deletion of Test Suite
		
		Thread.sleep(2000);
		ep.Delete();
		tcp.DelCopmYes();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		
		
		
		
		
	}
	
	
	
	
	

}
