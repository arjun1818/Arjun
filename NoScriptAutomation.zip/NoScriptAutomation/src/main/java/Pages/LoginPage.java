package Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.DriverUtils;



public class LoginPage extends DriverUtils {
	
	 WebDriver driver;
	 public LoginPage(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	 @FindBy(xpath="//button[@class='btn btn-sm acceptcookies cookie__btncustom']")
		private WebElement Accept;
	@FindBy(linkText="Sign In")
	private WebElement SignIn;
	@FindBy(xpath="//input[@id='username']")
	private WebElement Uname;
	@FindBy(xpath="//input[@id='password']")
	private WebElement Password;
	@FindBy(xpath="//input[@id='kc-login']")
	private WebElement signinbtn;
	
	@FindBy(xpath="//i[@class='fa fa-suitcase cust__icon']")
	private WebElement ChooseProj;
	
	@FindBy(xpath="//i[@class='fa fa-chevron-down']")
	private WebElement Dropdown;
	
	@FindBy(xpath="(//button[@aria-disabled='false'])[3]")
	private WebElement logout;

	public void Acceptclick() {
	clickOn(Accept);
}
	 public void SignInClick() {
			clickOn(SignIn);
			}
	 public void UnameEnter(String uname) {
		 sendtext(Uname,uname);
		 
	 }
	 public void ClearAndEnterUname(String clearuname) {
		 Uname.clear();
		 sendtext(Uname,clearuname);
	 }
	 public void Password1(String pass) {
		 sendtext(Password,pass);
	 }
	 public void SignInbtnclick() {
		 clickOn(signinbtn);
	 }
	 public void ProjClick() {
		 clickOn(ChooseProj);
	 }
	 public void Drop() {
		 clickOn(Dropdown);
	 }
	 public void Logout() {
		 clickOn(logout);
	 }

// }

}
