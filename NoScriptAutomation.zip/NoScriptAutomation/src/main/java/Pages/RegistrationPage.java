package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.DriverUtils;

public class RegistrationPage extends DriverUtils{
	 WebDriver driver;
	 public RegistrationPage(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	 @FindBy(xpath="//button[@class='btn btn-sm acceptcookies cookie__btncustom']")
		private WebElement Accept;
	@FindBy(linkText="Sign In")
	private WebElement SignIn;
	@FindBy(linkText="Sign Up")
	private WebElement SignUp;
	@FindBy(xpath="//input[@placeholder='Full name']")
	private WebElement FullName;
	@FindBy(xpath="//input[@name='email']")
	private WebElement Email;
	@FindBy(xpath="//input[@id='username']")
	private WebElement UserName;
	@FindBy(xpath="//input[@id='password']")
	private WebElement Password;
	@FindBy(xpath="//input[@id='confirmpassword']")
	private WebElement ConPassword;
	@FindBy(xpath="//div[contains(@class,'recaptcha-checkbox-checkmark')]")
	private WebElement Captcha;
	@FindBy(xpath="//input[@id='check1']")
	private WebElement Check1;
	@FindBy(xpath="//input[@id='check2']")
	private WebElement Check2;
	@FindBy(xpath="//button[@type='submit']")
	private WebElement Submit;
	

	public void Acceptclick() {
		clickOn(Accept);
	}
		 public void SignInClick() {
				clickOn(SignIn);
				}
		 public void SignUpPage() {
				clickOn(SignUp);
				}
		 
		 public void fullname(String fname) {
			 FullName.clear();
				sendtext(FullName,fname);
				}
		 public void EnterEmail(String email) {
			 Email.clear();
				sendtext(Email,email);
				}
		 public void username(String uname) {
			 UserName.clear();
				sendtext(UserName,uname);
				}
		 public void pass(String p1) {
			 Password.clear();
				sendtext(Password,p1);
				}
		 public void conpass(String p2) {
			 ConPassword.clear();
				sendtext(ConPassword,p2);
				}
		 public void captcha() {
			 
				clickOn(Captcha);
				}
		 public void check1() {
				clickOn(Check1);
				}
		 public void check2() {
				clickOn(Check2);
				}
		 public void submit() {
				clickOn(Submit);
				}
		 @FindBy(xpath="//select[@name='userType']")
			private WebElement usertype;
			
		 public void UserType() {
				clickOn(usertype);
			}
		 
		 @FindBy(xpath="//option[@value='new']")
			private WebElement newuser;
			
		 public void NewUser() {
				clickOn(newuser);
			}
		 
		 @FindBy(xpath="//option[@value='existing']")
			private WebElement existinguser;
			
		 public void ExistingUser() {
				clickOn(existinguser);
			}
		 
		 @FindBy(xpath="//input[@id='adminUsername']")
			private WebElement manageruname;
			
		 public void ManagerUname(String managername) {
			 manageruname.clear();
				sendtext(manageruname,managername);
				}
		 
		 @FindBy(xpath="//button[contains(@class,'btn btn-success right__btns pull-right line-height-2 ng-star-inserted')]")
			private WebElement verify;
			
		 public void Verify() {
				clickOn(verify);
			}
		 public void ClearAndEnterFullName(String clearname) {
			 FullName.clear();
			 sendtext(FullName,clearname);
		 }
		 
		 public void ClearAndEnterEmail(String clearemail) {
			 Email.clear();
			 sendtext(Email,clearemail);
		 }
		 
		 public void ClearAndEnterUname(String clearuname) {
			 UserName.clear();
			 sendtext(UserName,clearuname);
		 }
		 
		 public void ClearAndEnterpass(String clearpass) {
			 Password.clear();
			 sendtext(Password,clearpass);
		 }
		 
		 public void ClearAndEnterconpass(String clearconpass) {
			 ConPassword.clear();
			 sendtext(ConPassword,clearconpass);
		 }
		 
		 public void ClearAndEnterManager(String clearmanager) {
			 manageruname.clear();
			 sendtext(manageruname,clearmanager);
		 }
		 
		 
		 
		 
		 
		 
		 
}
