package testcases;

import static org.testng.Assert.assertTrue;

import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.LoginPage;
import Pages.TestComponentPage;

public class TestComponentCopy extends BaseTest1{
	
	@DataProvider(name="noskriptdata")
	
		public Object[][] noskriptdata() throws IOException {
			JsonObject jsonObject = BaseUtils.getTestData();
			JsonObject appData = jsonObject.getAsJsonObject("testsuitecrud");
			Object[][] testData = new Object[1][2];
			
			testData[0][0] = appData.get("Username").getAsString();
			testData[0][1] = appData.get("Password").getAsString();
			
		return testData;
		}
	
	@Test(dataProvider="noskriptdata")
	public void Condition(String uname,String pass) throws InterruptedException {
		
		TestComponentPage c1= new TestComponentPage(driver);
		LoginPage l1=new LoginPage(driver);
		l1.Acceptclick();
		Thread.sleep(2000);
		l1.SignInClick();
		Thread.sleep(2000);
		
		l1.UnameEnter(uname);
		Thread.sleep(2000);
		l1.Password1(pass);
		Thread.sleep(2000);
		
		l1.SignInbtnclick();
		Thread.sleep(2000);
		
		//l1.ProjClick();
		
		c1.FlowClick();
		Thread.sleep(2000);
		c1.TestComp();
		Thread.sleep(2000);
		c1.AppTestClick();
		Thread.sleep(2000);
		c1.Copy();
		Thread.sleep(2000);
		String actualString = driver.findElement(By.xpath("(//td[@class='col-md ng-star-inserted'])[1]")).getText();
		assertTrue(actualString.contains("Radio"));
		
		//component name null
		
		c1.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//component name with special characters
		
		c1.ClearAndEnterCompName("@test");
		c1.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//component name with space
		
		c1.ClearAndEnterCompName("test test");
		c1.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		//component name short
		
		c1.ClearAndEnterCompName("te");
		c1.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		
		//component name already exist
		
		c1.ClearAndEnterCompName("ifcondition");
		c1.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		
		//component name saved successfully
		
		c1.ClearAndEnterCompName("ifconditioncopy");
		
		
		c1.Save();
		Thread.sleep(2000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
		});
		Thread.sleep(2000);
//		String actualString1 = driver.findElement(By.xpath("(//td[@class='mat-cell cdk-cell cdk-column-moduleName mat-column-moduleName ng-star-inserted'])[1]")).getText();
//		assertTrue(actualString1.contains(" ifconditioncopy "));
		
}
}
