package testcases;
import java.io.IOException;


import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import Base.BaseTest1;
import Base.BaseUtils;
import Pages.AdminPage;


public class AdminTest extends BaseTest1{
	
		
		@DataProvider(name = "noskriptdata")
		public Object[][] webteststep() throws IOException {
			JsonObject jsonObject = BaseUtils.getTestData();
			JsonObject appData = jsonObject.getAsJsonObject("adminUser");
			Object[][] testData = new Object[1][4];
			testData[0][0] = appData.get("AdminU").getAsString();
			testData[0][1] = appData.get("AdminP").getAsString();
			testData[0][2] = appData.get("UserU").getAsString();
			testData[0][3] = appData.get("UserP").getAsString();

	 
			return testData;
		}
		
		//User approval and project allocation by Admin
		
		@Test(priority=0,dataProvider= "noskriptdata")
		public void UserApproval(String uname,String pass, String uuname, String upass) throws InterruptedException {
			
				
			AdminPage l1=new AdminPage(driver);
			l1.Acceptclick();
			Thread.sleep(2000);
			l1.SignInClick();
			Thread.sleep(2000);
		    l1.SignIn(uname,pass);
			Thread.sleep(2000);
	        l1.ProjClick();
			Thread.sleep(2000);
			l1.settings();
			Thread.sleep(2000);
			l1.ApproveUser();
			Thread.sleep(2000);
			//l1.SearchName("arjun");	
			Thread.sleep(2000);
			
			//Approve button click without selecting platform
			
			l1.Statusdrop();
			l1.StatusSelect();
			l1.EditUser1();
			Thread.sleep(2000);
			l1.Update();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});	
			
			//Approve button click without assigning project 
							
		    l1.PlatformSelect();
		    l1.SelectNoScript();
		    Thread.sleep(2000);
		    l1.Update();
		    Thread.sleep(2000);
		    SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});	
		    
		    //Assigning project without selecting role
				
			l1.ChProj();
			Thread.sleep(2000);
			l1.BtnSet();
			l1.Update();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//option[@value='0: Object']")).isDisplayed());
			});
			
			//Deselecting project and verifying
			
			l1.DeselectProj();
			l1.Reset();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//select[@name='selectedTechs'])[2]")).isDisplayed());
			});
			
			//Successfully approving user
			
			Thread.sleep(2000);
			l1.ChProj();
			l1.BtnSet();
			l1.role();
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[1]")).isDisplayed());
					
		    });
		    SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[2]")).isDisplayed());
					
			});
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[3]")).isDisplayed());
					
			});
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[5]")).isDisplayed());
					
				});
			l1.SetRole();
		    l1.Update();
		    
		    
//				l1.Callender();
//				l1.DateSelect();
		}
		
          //User Approval and project allocation by manager

		@Test(priority=1,dataProvider= "noskriptdata")
		public void UserApprovalUser(String uname,String pass, String uuname, String upass) throws InterruptedException {
			AdminPage l2=new AdminPage(driver);
			
			Thread.sleep(2000);
			l2.Acceptclick();
			Thread.sleep(2000);
			l2.SignInClick();
			Thread.sleep(2000);
		    l2.SignIn(uuname,upass);
			Thread.sleep(2000);
			l2.ProjClick();
			Thread.sleep(2000);
			l2.AdminLogout();
			l2.AdminLogoutOp();
	        
//			l2.settings();
//			Thread.sleep(2000);
//			l2.ApproveUser();
//			Thread.sleep(2000);
			//l1.SearchName("arjun");	
			Thread.sleep(2000);
			
			//Approve button click without selecting platform
			
			l2.Statusdrop();
			l2.StatusSelect();
			l2.EditUser1();
			Thread.sleep(2000);
			l2.Update();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});	
			
			//Approve button click without assigning project 
							
		    l2.PlatformSelect();
		    l2.SelectNoScript();
		    Thread.sleep(2000);
		    l2.Update();
		    Thread.sleep(2000);
		    SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});	
		    
		    //Assigning project without selecting role
				
			l2.ChProj();
			Thread.sleep(2000);
			l2.BtnSet();
			l2.Update();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div[@role='alertdialog']")).isDisplayed());
			});
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//option[@value='0: Object']")).isDisplayed());
			});
			
			//Deselecting project and verifying
			
			l2.DeselectProj();
			l2.Reset();
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//select[@name='selectedTechs'])[2]")).isDisplayed());
			});
			
			//Successfully approving user
			
			Thread.sleep(2000);
			l2.ChProj();
			l2.BtnSet();
			l2.role();
			
			Thread.sleep(2000);
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[1]")).isDisplayed());
					
		    });
		    SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[2]")).isDisplayed());
					
			});
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("(//span[@class='mat-option-text'])[3]")).isDisplayed());
					
			});
			
			l2.SetRole();
		    l2.Update();
			
}
}

